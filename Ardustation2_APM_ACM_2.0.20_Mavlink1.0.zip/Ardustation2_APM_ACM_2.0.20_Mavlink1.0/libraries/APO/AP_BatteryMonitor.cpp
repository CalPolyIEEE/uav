/*
 * AP_BatteryMonitor.cpp
 *
 */

#include "AP_BatteryMonitor.h"

namespace apo {

} // apo

// vim:ts=4:sw=4:expandtab
